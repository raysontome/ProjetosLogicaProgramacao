import java.util.Scanner;

public class ValordeN {

	private static Scanner ler;

	public static void main(String[] args) {
		int n, div = 0;
		ler = new Scanner(System.in);
		System.out.println("Digite o valor de N: ");
		n = ler.nextInt();

		long start = System.currentTimeMillis();
		for (int j = 2; j <= n; j++) {
			div = 0;
			for (int i = 1; i <= j; i++) {
				if (j % i == 0) {
					div++;
				}
			}

			if (div == 2) {
				System.out.println(j);
			}
		}
		long finish = System.currentTimeMillis();
		long diff = finish - start;
		System.out.println(diff / 1000.0);
	}
}