import java.util.Scanner;

/**
 * Entrada: N inteiro Saida: Todos os numeros primos entre 2 e N
 */

public class VerificacaoPrimos {

	public static void main(String[] args) {
		int x, div = 0;
		@SuppressWarnings("resource")
		Scanner ler = new Scanner(System.in);
		System.out.println("Digite o valor de X: ");
		x = ler.nextInt();

		for (int i = 1; i <= x; i++) {
			if (x % i == 0) {
				div++;
			}
		}

		if (div == 2) {
			System.out.println("O NUMERO É PRIMO");
		} else {
			System.out.println("O NUMERO NAO É PRIMO");
		}
	}
}