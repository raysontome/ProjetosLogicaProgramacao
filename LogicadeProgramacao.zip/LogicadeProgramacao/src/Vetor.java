import java.util.*;

public class Vetor {

	public static void main(String[] args) {

		double maiornota = 0;
		int maiormatricula = 0;
		int num = 0;
		int cont, opcao = 0;
		int[] matriculas = { 1256, 1042, 1232, 1271, 1152, 1132, 1213, 1112, 1020, 1201 };
		String[] nomes = { "Ailton", "Marlos", "Rebeca", "Marco", "Jane", "Pedro", "Raquel", "Paulo", "Vitor", "Mara" };
		double[] notas = { 8.0, 7.1, 8.2, 9.1, 6.3, 8.2, 8.5, 7.8, 8.6, 6.5 };

		Scanner ler = new Scanner(System.in);

		for (int i = 0; i < 10; i++) {
			do {

				System.out.println("1) Para exibir a lista: "
						+ "2) Informe uma matrícula e exiba o índice do vetor caso nao, informar se a matrícula é inexistente: "
						+ "3) Informe uma matrícula e exiba a matrícula, nome e nota caso nao, informar se a matrícula é inexistente: "
						+ "4) Informar a maior nota e exiba com a matrícula e nome ");
				opcao = ler.nextInt();

				if (opcao == 1) {
					for (cont = 0; cont <= matriculas.length; cont++) {
						System.out.printf("%-12s %-12s %-12s \n", matriculas[cont], nomes[cont], notas[cont]);
					}
				}
				boolean existe = false;
				if (opcao == 2) {
					System.out.println("Digite a matrícula para exibir o índice do vetor:  ");
					num = ler.nextInt();
					for (cont = 0; cont <= matriculas.length - 1; cont++) {

						if (matriculas[cont] == num) {
							System.out.println("O índice é:  " + cont);
							existe = true;
						}

						if (cont == matriculas.length - 1 && existe == false) {
							System.out.println("A matrícula digitada é inexistente, tente novamente!");
						}
					}
				}

				if (opcao == 4) {
					System.out.println("Digite uma matrícula para informar a maior nota, matrícula e nome: ");
					for (int j = 0; j > notas.length; j++) {
						if (notas[j] < maiornota) {
							maiornota = notas[j];
							maiormatricula = j;
						}
					}
					System.out.printf("%-12s %-12s %-12s \n", matriculas[maiormatricula], nomes[maiormatricula],
							notas[maiormatricula]);
				}

				while (true) {
					if (opcao == 3) {
						System.out.println("Digite a matrícula para exibir matrícula, nome e nota: ");
						num = ler.nextInt();
						if (num == 0) {
							break;
						}
						for (cont = 0; cont <= matriculas.length; cont++) {
							if (matriculas[i] == num) {
								System.out.printf("%-12s %-12s %-12s", matriculas[cont], nomes[cont], notas[cont]);
							} else if (cont == matriculas.length - 1) {
								System.out.println("A matrícula digitada é inexistente, tente novamente!");
							}
						}
					}
				}

			} while (opcao != 4);
		}
	}
}
// Passo 6: Realize uma busca para determinar a maior nota. Imprima a
// matrícula, o nome e a nota.
// Passo 7: Ordene os vetores de acordo com as matrículas utilizando
// ordenação por seleção.
// Passo 8: Imprima os vetores na forma tabular.
// Passo 9: Ordene os vetores de acordo com as notas utilizando ordenação por
// trocas.
// Passo 10: Imprima os vetores na forma tabular.