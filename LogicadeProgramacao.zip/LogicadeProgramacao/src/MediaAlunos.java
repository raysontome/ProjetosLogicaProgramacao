public class MediaAlunos {
	public static void main(String[] args) {
		// passo 1
		int[] matriculas = { 1020, 1042, 1112, 1132, 1152, 1201, 1213, 1232, 1256, 1271 };
		String[] nomes = { "Ailton", "Marlos", "Rebeca", "Marco", "Jane", "Pedro", "Raquel", "Paulo", "Vitor", "Mara" };
		double[][] notas = { { 7.5, 8.9, 6.5 }, { 8.2, 7.3, 9.4 }, { 10.0, 9.6, 7.1 }, { 6.8, 7.5, 8.1 },
				{ 8.8, 7.4, 9.2 }, { 8.3, 7.9, 9.0 }, { 7.2, 8.7, 9.8 }, { 8.3, 7.7, 8.9 }, { 7.8, 7.7, 8.5 },
				{ 8.0, 7.0, 9.0 } };
		// passo 5
		double[] medias = new double[10];

		// passo 3
		DataPrint(matriculas, nomes, notas);
	}

	// passo 2
	static void DataPrint(int[] matr, String[] nom, double[][] nota) {
		System.out.printf("%-7s %-9s %7s %7s %7s \n", "matr.", "nome", "nota1", "nota2", "nota3");
		System.out.println("_________________________________________");
		for (int i = 0; i < matr.length; i++) {
			System.out.printf("%-7d%-9s%7.1f%7.1f%7.1f\n", matr[i], nom[i], nota[i][0], nota[i][1], nota[i][2]);
		}
		System.out.print("\n\n\n");
	}

	// passo 4
	static double[] MediaAluno(double[][] notas) {
		double[] media = new double[10];
		double soma = 0;
		double divisao = 0;
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 3; j++) {
				soma = soma + notas[i][j];
			}
			divisao = soma / 3;
		}
		for (int i = 0; i < media.length; i++) {
			media[i] = divisao;
		}
		return media;
	}

	// passo 6
	public static void mediaAll(String[] nomes, double[][] notas) {
		for (int i = 0; i < nomes.length; i++) {
			System.out.print(nomes[i] + ":	");
			media(i, notas);
		}
	}

	public static void media(int i, double[][] notas) {
		double somatorio = 0;

		for (int j = 0; j <= 2; j++) {
			somatorio = somatorio + notas[i][j];
		}
		System.out.println(somatorio / 3);
	}

	// passo 7
	public boolean buscaMatricula(int matricula, int[] matriculas) {
		Boolean existe = false;

		for (int i = 0; i < matriculas.length; i++) {

			if (matriculas[i] == matricula) {
				existe = true;
			}
		}
		return true;
	}
}