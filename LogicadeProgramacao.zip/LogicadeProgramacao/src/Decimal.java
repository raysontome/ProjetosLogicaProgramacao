import javax.swing.JOptionPane;

public class Decimal {
	public static void main(String[] args) {
		int binarioDecimal = 0;
		int controle = 1;
		String aux = JOptionPane.showInputDialog("Informe um número binário");
		String n = aux;
		for (int i = 0; i <= aux.length(); i++) {

			// senao for maior q n.length() entregue o ultimo numero
			String g = n.length() > 0 ? n.substring(n.length() - 1) : "0";

			// n recebe n - o numero entregue a variavel g
			n = n.length() > 0 ? n.substring(0, n.length() - 1) : "";

			// cálculo
			binarioDecimal += controle * Integer.parseInt(g);
			controle *= 2;
		}
		JOptionPane.showMessageDialog(null, "Resultado em decimal: " + binarioDecimal);
	}
}