import java.util.Scanner;

public class CriarConta {
	public static void main(String[] args) {
		double saldo, valor;
		int opção;
		Scanner ler = new Scanner(System.in);
		System.out.print("Seja bem vindo! Por gentileza informar o valor para abertura da conta corrente: ");
		valor = ler.nextDouble();
		saldo = abrir(valor);

		do {
			System.out.println("Informe\n1-Depósito\n2-Saque\n3-Juros\n4-Encerrar");
			System.out.print("Opção: ");
			opção = ler.nextInt();

			switch (opção) {

			case 1:
				System.out.println("Por gentileza, digite o valor do depósito: ");
				valor = ler.nextDouble();
				saldo = deposito(saldo, valor);
				break;

			case 2:
				System.out.println("Por gentileza, digite o valor do saque: ");
				valor = ler.nextDouble();
				saldo = saque(saldo, valor);
				break;

			case 3:
				System.out.println("Por gentileza, informe o valor da taxa: ");
				valor = ler.nextDouble();
				saldo = lancaJuros(saldo, valor);
				break;

			case 4:
				encerrar(saldo);
				break;

			default:
				System.out.println("A opção está inválida.");
			}
		} while (opção != 4);
	}

	static double abrir(double valor) {
		System.out.printf("O valor corrente é: %10.2f\n\n", valor);
		return valor;
	}

	static double deposito(double saldo, double valor) {
		double soma = saldo + valor;
		System.out.printf("O valor corrente é : %10.2f\n\n", soma);
		return soma;
	}

	static double saque(double saldo, double valor) {
		double diferenca = saldo - valor;
		if (diferenca >= 0) {
			System.out.printf("O valor corrente é :%10.2f\n\n ", diferenca);
			return diferenca;
		} else {
			System.out.println("Saldo insuficiente !");
			System.out.println("Operação nao realizada");
			System.out.printf("O valor corrente é :%10.2f\n\n ", saldo);
			return saldo;
		}

	}

	static double lancaJuros(double saldo, double taxa) {
		double juros = (1 + taxa) * saldo;
		System.out.printf("O valor corrente é : %10.2f\n\n", juros);
		return juros;
	}

	static void encerrar(double saldo) {
		System.out.printf("Atualmente o valor da conta corrente é:%10.2f\n\n ", saldo);
		System.out.println("Prezado,a conta está encerrada!");
	}
}