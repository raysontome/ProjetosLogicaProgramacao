import java.util.Scanner;

public class ContaCorrente {

	public static void main(String[] args) {
		double saldo, valor;
		int opcao;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Informe o valor de abertura: ");
		valor = scanner.nextDouble();
		saldo = abrir(valor);

		do {
			System.out.println("Informe\n1-Deposito\n2-Saque\n3-Juros\n4-Encerrar");
			System.out.print("Opcao: ");
			opcao = scanner.nextInt();

			switch (opcao) {
			case 1:
				System.out.println("Informe o valor do deposito");
				valor = scanner.nextDouble();
				saldo = valor + saldo;
				System.out.println("O valor corrente da conta é" + saldo);
				break;

			case 2:
				System.out.println("Informe o valor do saque");
				valor = scanner.nextDouble();
				if (saldo < valor) {
					System.out.println("O saldo insuficiente!\nOperacao nao realizada");
				} else
					saldo = saldo - valor;
				System.out.println("O valor corrente da conta é" + saldo);
				break;

			case 3:
				System.out.println("A taxa de juros é 10%");
				saldo = saldo * 1.10;
				System.out.println("O valor corrente da conta é" + saldo);
				break;

			case 4:
				System.out.println("O valor de encerramento da conta é :" + saldo);
				System.out.println("A conta está encerrada");
				break;

			default:
				System.out.println("Opcao invalida!");
			}

		} while (opcao != 4);
	}

	static double abrir(double valor) {
		System.out.printf("O valor corrente é: %10.2f\n\n", valor);

		return valor;
	}

	static double deposito;
}